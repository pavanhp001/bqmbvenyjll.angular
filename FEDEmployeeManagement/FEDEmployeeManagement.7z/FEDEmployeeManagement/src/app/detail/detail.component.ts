import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Employee } from '../employee';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
//import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  employee: Employee;
  employee$: Observable<Employee[]>;
  id: number;

  constructor(
    private empService: EmployeeService,
    private route: ActivatedRoute
    ) { }


  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
    for (let i = 0; i < this.empService.getEmployees().length; i++) {
      if (this.empService.getEmployees()[i].id === this.id) {
        this.employee = this.empService.getEmployees()[i];
        break;
      }
    }
  }
}
