import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  showEditFlag = false;
  employee: Employee;
  employees: Employee[];

  constructor(private empService: EmployeeService) { }
  ngOnInit(): void {
    this.employees = this.empService.getEmployees();
  }

  headers = ['Emp Id', 'Name', 'Location', 'Email', 'Mobile', 'Edit', 'Delete'];
  employeeListHeader = ['id', 'name', 'location', 'email', 'mobile'];

  editEmployee(emp: Employee) {
    this.showEditFlag = true;
    this.employee = emp;
    console.log('editEmployee in list emp= ' + this.employee.id);
  }
  removeEmployee(emp: Employee) {
    console.log(emp.id);
    console.log('employees.length: ' + this.employees.indexOf(emp));
    for (let employee of this.employees) {
      if (employee.id == emp.id) {
        this.employees.splice(this.employees.indexOf(employee), 1);
        break;
      }
    }

    console.log('employees.length: ' + this.employees.length);
  }

  displayCounter(emp) {
    console.log('employeee in parant');
    console.log(emp);
    this.employee = emp;
    console.log('updated name: ' + emp.name);
    const updatedemployee = this.employees.find(n => n.id == emp.id);
    console.log(updatedemployee.name);
    if (updatedemployee != undefined) {
      for (let i = 0; i < this.employees.length; i++) {
        if (this.employees[i].id === emp.id) {
          this.employees[i] = emp;
          console.log('updated employee= ' + this.employees[i].name);
          break;
        }
      }
    }
  }
}
